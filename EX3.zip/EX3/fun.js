var date =Date();
document.write(date , "<br >");


function show(){
    document.getElementById("demo").innerHTML = "HELLO WORLD";
}

function mins (){
var x = 5;
var y = 6 ;
var min = x- y ; 
document.write(min,"<br>");
}

mins () ;

var a =5;
var b =15; 
document.write(a==b,"<br>");

var x =15;
var k =13; 

document.write((a<=b) ||(x==k) , "<br>");
document.write((a>=b) && (x<=k) ,"<br>");

function zarb(a,b){
   alert("5*5  =" +a*b);
}
zarb(5,5);
alert
function division(){
    alert("8/2  = "+8/2);
}
division();



